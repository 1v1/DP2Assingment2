package it.polito.dp2.FDS.sol2;

public class EmptyFileException extends Exception{
	
	EmptyFileException()
	{
		super();
	}
	
	EmptyFileException(String msg)
	{
		super(msg);
	}

}
